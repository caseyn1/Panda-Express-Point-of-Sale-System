import React, { useEffect, useState } from 'react';
import { Tab, Tabs } from "../components/Tabs";
import { Item } from '../components/Item';
import { executePostRequest } from '../util/postRequest';

export const PointOfSale = () => {
    const tabs = ["MEAL", "SIDE", "ENTREE", "APPETIZER", "DRINK"];

    // Helper function to generate an empty order structure
    const generate_empty_order = () => {
        const empty_order = {};
        tabs.forEach(tab => {
            empty_order[tab] = [];
        });
        return empty_order;
    };

    const [menu_items, set_menu_items] = useState([]);
    const [order, set_order] = useState(generate_empty_order());
    const [total, setTotal] = useState(0);
    const [current_tab, set_current_tab] = useState("MEAL");
    const [employee_id, set_employee_id] = useState(0)

    // Fetch menu items from the API
    const fetchMenuItems = async () => {
        try {
            const response = await fetch(`http://localhost:8000/items`);
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    
            const data = await response.json();
            set_menu_items(data); // Set fetched data directly
        } catch (error) {
            console.error("Error fetching menu items:", error);
        }
    };

    // Determine the next tab based on the updated order
    const check_for_next_tab = (updatedOrder) => {
        if (current_tab === "MEAL"){
            if (updatedOrder["MEAL"] && updatedOrder["MEAL"].length === 1) {
                return tabs[tabs.indexOf("MEAL") + 1];
            }
        }else if (current_tab == "SIDE" ){
            const selectedMeal = updatedOrder["MEAL"][0];
            const nextTab = tabs[tabs.indexOf("SIDE") + 1];
            
            if (selectedMeal) {
                if (selectedMeal.name === "Bowl" && updatedOrder["SIDE"] && updatedOrder["SIDE"].length === 1) {
                    return nextTab;
                } else if (selectedMeal.name === "Plate" && updatedOrder["SIDE"] && updatedOrder["SIDE"].length === 2) {
                    return nextTab;
                } else if (selectedMeal.name === "Bigger Plate" && updatedOrder["SIDE"] && updatedOrder["SIDE"].length === 2) {
                    return nextTab;
                }
            }

            return "SIDE"
        }else if(current_tab == "ENTREE"){
            const selectedEntree = updatedOrder["ENTREE"][0];
            const nextTab = tabs[tabs.indexOf("ENTREE") + 1];
            
            if (selectedEntree) {
                if (selectedEntree.name === "Bowl" && updatedOrder["ENTREE"] && updatedOrder["ENTREE"].length === 1) {
                    return nextTab;
                } else if (selectedEntree.name === "Plate" && updatedOrder["ENTREE"] && updatedOrder["ENTREE"].length === 2) {
                    return nextTab;
                } else if (selectedEntree.name === "Bigger Plate" && updatedOrder["ENTREE"] && updatedOrder["ENTREE"].length === 2) {
                    return nextTab;
                }
            }

            return "ENTREE"
        }
        return "MEAL"; // Default or initial tab
    };

    // Add item to order and update the current tab accordingly
    const add_item_to_order = (item) => {
        set_order(prevOrder => {
            const updatedOrder = {
                ...prevOrder,
                [item.item_type]: [...prevOrder[item.item_type], item]
            };
            
            // Update current tab based on the newly updated order
            set_current_tab(check_for_next_tab(updatedOrder));
            setTotal(total + parseFloat(item.price));
            
            return updatedOrder;
        });
    };

    const handleEmployeeIdChange = (e) => {
        set_employee_id(e.target.value)
    }

    const checkout = async() => {
        try{
            const response = await executePostRequest('http://localhost:8000/items', {
                order,
                total,
                employee_id
            })

            console.log(response)
        }catch(error){
            console.log(error)
        }
    }

    function formatItem(itemName, price, width = 40) {
        const formattedLine = itemName.padEnd(width - price.length, ".") + price;
        return formattedLine;
    }

    // Fetch menu items on initial render
    useEffect(() => {
        fetchMenuItems();
        return () => set_menu_items([]); // Cleanup function
    }, []);

    return (
        <div className='flex flex-between w-[95%]'>
            <Tabs active={current_tab}>
                {tabs.map(tab => (
                    <Tab label={tab} key={tab}>
                        {
                            menu_items.map(item => 
                                item.item_type === tab && (
                                    <Item key={item.id} item={item} onClick={add_item_to_order} />
                                )
                            )
                        }
                    </Tab>
                ))}
            </Tabs>
            <div className='w-[25%] text-left p-10'>
                {
                    tabs.map(tab => {
                        return (
                            <div key={tab}>
                                <ul>
                                    {order[tab].map((item, idx) => (
                                        <li key={idx}>{formatItem(item.name, item.price, 50)}</li>
                                    ))}
                                </ul>
                            </div>
                        );
                    })
                }
                <hr className='m-10'/>
                <h3>Total: ${total}</h3>
                <div className='flex'>
                    <input type="number" class="w-full bg-transparent placeholder:text-slate-400 text-slate-700 text-sm border border-slate-200 rounded-md px-3 py-1.5 transition duration-300 ease focus:outline-none focus:border-slate-400 hover:border-slate-300 shadow-sm focus:shadow" placeholder="Employee ID" value={employee_id} onChange={handleEmployeeIdChange} />
                    <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" onClick={() => checkout()}>Checkout</button>
                </div>
            </div>
        </div>
    );
};
