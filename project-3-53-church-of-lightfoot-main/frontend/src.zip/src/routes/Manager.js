import React, { act, useEffect, useState } from 'react';
import { Tab, Tabs } from '../components/Tabs';
import { Employee } from '../components/Employee';
import { EmployeeAdder, EmployeeAdderPopUp } from '../components/EmployeeAdder';
import { executePostRequest } from '../util/postRequest';

export const Manager = () => {
    const postActions = Object.freeze({
        ADD_EMPLOYEE : 0,
        DELETE_EMPLOYEE : 1,
        CHANGE_STATUS : 2
    });

    const tabs = ["EMPLOYEES", "INVENTORY", "SALES HISTORY", "USAGE CHART", "SERVICES"];

    const [employees, set_employees] = useState([]);
    const [currEmployee, setCurrEmployee] = useState(null);
    const [employeePopUp, setEmployeePopUp] = useState(false);
    const [employeeAdder, setEmployeeAdder] = useState(false);

    // Fetch employees from the API
    const fetchEmployees = async () => {
        try {
            const response = await fetch(`http://localhost:8000/employees`);
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    
            const data = await response.json();
            set_employees(data); // Set fetched data directly
        } catch (error) {
            console.error("Error fetching employees:", error);
        }
    };

    // Fetch employees on initial render
    useEffect(() => {
        fetchEmployees();
        return () => set_employees([]); // Cleanup function
    }, []);

    // Employee info popup window functions.
    const openPopup = (employee) => {
        setCurrEmployee(employee);
        setEmployeePopUp(true);
    };
    const closePopup = () => {
        setEmployeePopUp(false);
        setCurrEmployee(null);
    };

    // Employee adder function
    const addEmployee = async (first_name, last_name, position, pin_id) => {
        const action = postActions.ADD_EMPLOYEE;
        try {
            const response = await executePostRequest('http://localhost:8000/employees/add', {
                first_name,
                last_name,
                position,
                pin_id
            })
            console.log(response)
        } catch (error) {
            console.log(error)
        }

        fetchEmployees();
    };

    // Employee deleter function
    const deleteEmployee = async (employee_id) => {
        const action = postActions.DELETE_EMPLOYEE;
        try {
            const response = await executePostRequest('http://localhost:8000/employees/delete', {
                employee_id
            })
            console.log(response)
        } catch (error) {
            console.log(error)
        }

        fetchEmployees();
    };

    return (
        <div>
            <Tabs active={"EMPLOYEES"}> 
                {/* Default to employee view */}
                <Tab label={tabs.at(0)} key={tabs.at(0)}>
                    {/* Lists all employees in the database with their names and IDs. */}
                    {employees.map(employee => (
                            <Employee key={employee.employee_id} employee={employee} onClick={openPopup} />
                        )
                    )}
                    <EmployeeAdder onClick={setEmployeeAdder} />

                    {/* Employee Pop-up window that is dependent on the employee with the clicked Info. */}
                    {employeePopUp && (
                        <div className="fixed top-[50%] left-[50%] w-[25%] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-white rounded-md border border-gray-300">
                            <h3 className="text-lg font-medium">{currEmployee.first_name} {currEmployee.last_name}</h3>
                            <p>Employee ID: <b>{currEmployee.employee_id}</b></p>
                            <p>Position: <b>{currEmployee.position}</b></p>
                            <p>Status: <b>{currEmployee.is_active ? "Active" : "Not Active"}</b></p>
                            <p>PIN: <b>{currEmployee.pin_id}</b></p>
                            <button className="ml-[75%] px-3 py-1 bg-purple-500 text-white rounded-md" onClick={closePopup}>Close</button>
                        </div>
                    )}

                    {/* Employee Adder Pop-up window. */}
                    {employeeAdder && (
                        <EmployeeAdderPopUp onClose={setEmployeeAdder} onAdd={addEmployee} />
                    )}
                </Tab>
                <Tab label={tabs.at(1)} key={tabs.at(1)}>
                    
                </Tab>
                <Tab label={tabs.at(2)} key={tabs.at(2)}>
                    
                </Tab>
                <Tab label={tabs.at(3)} key={tabs.at(3)}>
                    
                </Tab>
                <Tab label={tabs.at(4)} key={tabs.at(4)}>
                    
                </Tab>
            </Tabs>
        </div>
    );
};
