// Employee component: has ID, first name, last name, position, active status, and PIN

import React from 'react';

export const Employee = ({onClick, employee}) => {
    // squared display that highlights the border when selected
    return (
        <div className="border border-gray-300 rounded-lg p-4 mb-4">
            <div className="flex justify-between">
                <div>
                    <h3 className="text-lg font-medium">{employee.first_name} {employee.last_name}</h3>
                    <p className="text-sm text-gray-700">ID: {employee.employee_id}</p>
                </div>
                <button className="px-3 py-1 bg-purple-500 text-white rounded-md" onClick={() => onClick(employee)}>Info</button>
            </div>
        </div>
    );
}