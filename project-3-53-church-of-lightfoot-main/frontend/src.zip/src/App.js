import logo from './logo.svg';
import './App.css';
import { PointOfSale } from './routes/PointOfSale';
import { Manager } from './routes/Manager';

import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/POS">
          <Route index element={<PointOfSale/>} />
        </Route>
        <Route path="/manager">
          <Route index element={<Manager/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
