import React, { useEffect, useState } from "react";
import { Tab, Tabs } from "../components/Tabs";
import * as EmployeeFunctions from "../components/Employee";
import * as InventoryItem from "../components/InventoryItem";

export const Manager = () => {
  const tabs = [
    "EMPLOYEES",
    "INVENTORY",
    "SALES HISTORY",
    "USAGE CHART",
    "SERVICES",
  ];

  const [employees, setEmployees] = useState([]);
  const [currEmployee, setCurrEmployee] = useState(null);
  const [employeePopUp, setEmployeePopUp] = useState(false);
  const [employeeAdder, setEmployeeAdder] = useState(false);

  const [inventory, setInventory] = useState([]);

  const cleanup = () => {
    setEmployees([]);
    setInventory([]);
  };

  // Fetch data on initial render
  useEffect(() => {
    EmployeeFunctions.fetchEmployees(setEmployees);
    InventoryItem.fetchInventory(setInventory);

    console.log(inventory);

    return () => cleanup; // Call cleanup
  }, []);

  // Employee info popup window functions.
  const openPopup = (employee) => {
    setCurrEmployee(employee);
    setEmployeePopUp(true);
  };
  const closePopup = () => {
    setEmployeePopUp(false);
    setCurrEmployee(null);
  };

  // Employee adder function
  const addEmployee = async (first_name, last_name, position, pin_id) => {
    EmployeeFunctions.addEmployee(
      first_name,
      last_name,
      position,
      pin_id,
      setEmployeeAdder,
      setEmployees
    );
  };

  // Employee deleter function
  const deleteEmployee = async () => {
    EmployeeFunctions.deleteEmployee(
      currEmployee,
      setEmployeePopUp,
      setEmployees
    );
  };

  return (
    <div>
      <Tabs active={"EMPLOYEES"}>
        {/* Default to employee view */}
        <Tab label={tabs.at(0)} key={tabs.at(0)}>
          {/* Lists all employees in the database with their names and IDs. */}
          {employees.map((employee) => (
            <EmployeeFunctions.Employee
              key={employee.employee_id}
              employee={employee}
              onClick={openPopup}
            />
          ))}
          <EmployeeFunctions.EmployeeAdder onClick={setEmployeeAdder} />

          {/* Employee Pop-up window that is dependent on the employee with the clicked Info. */}
          {employeePopUp && (
            <EmployeeFunctions.EmployeePopup
              employee={currEmployee}
              onClose={closePopup}
              onDelete={deleteEmployee}
            />
          )}

          {/* Employee Adder Pop-up window. */}
          {employeeAdder && (
            <EmployeeFunctions.EmployeeAdderPopUp
              onClose={setEmployeeAdder}
              onAdd={addEmployee}
            />
          )}
        </Tab>
        <Tab label={tabs.at(1)} key={tabs.at(1)}>
          <div class="absolute m-2">
            <table class="table-fixed">
              <thead class="text-lg font-medium">
                <tr class="bg-gray-100">
                  <th class="px-[20px] p-2 border-t border-b border-l text-center">ID</th>
                  <th class="px-[20px] p-2 border-t border-b border-l text-center">Name</th>
                  <th class="px-[20px] p-2 border-t border-b border-l text-center">Amount in Stock</th>
                  <th class="px-[20px] p-2 border-t border-b border-l text-center">Max Stock</th>
                  <th class="px-[20px] p-2 border-t border-b border-l text-center">Unit</th>
                  <th class="px-[20px] p-2 border-t border-b border-l border-r text-center">Percent</th>
                </tr>
              </thead>
              {inventory.map((inventoryItem) => (
                <InventoryItem.Item
                  key={inventoryItem.ingredient_id}
                  item={inventoryItem}
                />
              ))}
            </table>
          </div>
        </Tab>
        <Tab label={tabs.at(2)} key={tabs.at(2)}></Tab>
        <Tab label={tabs.at(3)} key={tabs.at(3)}></Tab>
        <Tab label={tabs.at(4)} key={tabs.at(4)}></Tab>
      </Tabs>
    </div>
  );
};
