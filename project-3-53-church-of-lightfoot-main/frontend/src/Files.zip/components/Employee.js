// Employee component: has ID, first name, last name, position, active status, and PIN

import React from "react";
import { executeRequest } from "../util/postRequest";

// ==================================
// Backend interactivity functions
// ==================================

export const fetchEmployees = async (setEmployees) => {
  try {
    const response = await fetch(`http://localhost:8000/employees`);
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

    const data = await response.json();
    setEmployees(data); // Set fetched data directly
  } catch (error) {
    console.error("Error fetching employees:", error);
  }
};

export const addEmployee = async (
  first_name,
  last_name,
  position,
  pin_id,
  setEmployeeAdder,
  setEmployees
) => {
  try {
    const response = await executeRequest(
      "http://localhost:8000/employees/add",
      {
        first_name,
        last_name,
        position,
        pin_id,
      },
      "POST"
    );
    if (response === 200) {
      setEmployeeAdder(false);
      fetchEmployees(setEmployees);
    }
  } catch (error) {
    console.error("Error adding employee:", error);
  }
};

export const deleteEmployee = async (
  employee,
  setEmployeePopUp,
  setEmployees
) => {
  const id = employee.employee_id;
  try {
    const response = await executeRequest(
      `http://localhost:8000/employees/${id}`,
      { id },
      "DELETE"
    );
    if (response === 200) {
      setEmployeePopUp(false);
      fetchEmployees(setEmployees);
    }
  } catch (error) {
    console.error("Error deleting employee:", error);
  }
};

// ==================================
// HTML-related functions
// ==================================

// This is the "card" used for each employee
export const Employee = ({ onClick, employee }) => {
  return (
    <div className="border border-gray-300 rounded-lg p-4 mb-4">
      <div className="flex justify-between">
        <div>
          <h3 className="text-lg font-medium">
            {employee.first_name} {employee.last_name}
          </h3>
          <p className="text-sm text-gray-700">ID: {employee.employee_id}</p>
        </div>
        <div className="flex justify-between mt-4">
          <button
            className="px-3 py-1 bg-purple-500 text-white rounded-md"
            onClick={() => onClick(employee)}
          >
            Info
          </button>
        </div>
      </div>
    </div>
  );
};

// Popup window that displays the currently selected employee's information
export const EmployeePopup = ({ employee, onClose, onDelete }) => {
  return (
    <div className="fixed top-[50%] left-[50%] w-[25%] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-white rounded-md border border-gray-300">
      <h3 className="text-lg font-medium">
        {employee.first_name} {employee.last_name}
      </h3>
      <p>
        Employee ID: <b>{employee.employee_id}</b>
      </p>
      <p>
        Position: <b>{employee.position}</b>
      </p>
      <p>
        Status: <b>{employee.is_active ? "Active" : "Not Active"}</b>
      </p>
      <p>
        PIN: <b>{employee.pin_id}</b>
      </p>
      <div className="flex justify-between mt-4">
        <button
          className="px-3 py-1 bg-purple-500 text-white rounded-md"
          onClick={onDelete}
        >
          Delete Employee
        </button>
        <button
          className="px-3 py-1 bg-purple-500 text-white rounded-md"
          onClick={onClose}
        >
          Close
        </button>
      </div>
    </div>
  );
};

// This is just a fancy button that will be placed after all the employee cards
export const EmployeeAdder = ({ onClick }) => {
  return (
    <div className="rounded-lg p-4 mb-4">
      <button
        className="w-[100%] h-[100%] px-3 py-1 bg-purple-500 text-white rounded-md"
        onClick={() => onClick(true)}
      >
        Add
      </button>
    </div>
  );
};

// Popup window that gives options to add an employee
export const EmployeeAdderPopUp = ({ onClose, onAdd }) => {
  return (
    <div className="fixed top-[50%] left-[50%] w-[40%] translate-x-[-50%] translate-y-[-50%] p-[20px] bg-white rounded-md border border-gray-300">
      <h3 className="text-lg font-medium">Add New Employee</h3>
      <div>
        <div className="inline-flex mt-4">
          <p className="w-[100px]">First Name:</p>
          <input className="border ml-4" type="text" id="firstName" />
        </div>
        <div className="inline-flex mt-4">
          <p className="w-[100px]">Last Name:</p>
          <input className="border ml-4" type="text" id="lastName" />
        </div>
        <div className="inline-flex mt-4">
          <p className="w-[100px]">Position:</p>
          <input className="border ml-4" type="text" id="position" />
        </div>
        <div className="inline-flex mt-4">
          <p className="w-[100px]">PIN:</p>
          <input className="border ml-4" type="text" id="pin" />
        </div>
      </div>
      <div className="flex justify-between mt-4">
        <button
          className="px-3 py-1 bg-purple-500 text-white rounded-md"
          onClick={() => onClose(false)}
        >
          Close
        </button>
        <button
          className="px-3 py-1 bg-purple-500 text-white rounded-md"
          onClick={() =>
            onAdd(
              document.getElementById("firstName").value,
              document.getElementById("lastName").value,
              document.getElementById("position").value,
              document.getElementById("pin").value
            )
          }
        >
          Add
        </button>
      </div>
    </div>
  );
};
