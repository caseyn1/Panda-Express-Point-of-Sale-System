// Inventory component: ID, name, current stock, max stock, unit, percent

import React from "react";

export const fetchInventory = async (setInventory) => {
  try {
    const response = await fetch(`http://localhost:8000/inventory`);
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

    const data = await response.json();
    setInventory(data); // Set fetched data directly
  } catch (error) {
    console.error("Error fetching employees:", error);
  }
};

export const Item = ({item}) => {
  const getPercent = (dividend, divisor) => {
    return Math.round((dividend / divisor) * 100)
  }

  // Return table components
  return (
    <tbody>
      <tr>
        <td class="p-2 border-b border-l text-center">{item.ingredient_id}</td>
        <td class="p-2 border-b border-l text-left">{item.name}</td>
        <td class="p-2 border-b border-l text-left">{Math.round(item.quantity_stock * 100) / 100}</td>
        <td class="p-2 border-b border-l text-left">{item.max_threshold}</td>
        <td class="p-2 border-b border-l text-center">{item.unit}</td>
        <td class="p-2 border-b border-l border-r text-center">{getPercent(item.quantity_stock, item.max_threshold)}</td>
      </tr>
    </tbody>
  );
};
